#include "pi_controller.h"

void pi_init(PIController* pi, float kp, float ki, float min, float max) {
    pi->kp = kp; pi->ki = ki;
    pi->output_min = min; pi->output_max = max;
    pi->integral = 0.0f; pi->output = 0.0f;
}

void pi_reset(PIController* pi) {
    pi->integral = 0.0f; pi->output = 0.0f;
}

float pi_update(PIController* pi, float error, float dt) {
    pi->integral += error * pi->ki * dt;
    
    // Anti-windup
    if (pi->integral > pi->output_max) pi->integral = pi->output_max;
    if (pi->integral < pi->output_min) pi->integral = pi->output_min;
    
    pi->output = (error * pi->kp) + pi->integral;
    
    if (pi->output > pi->output_max) pi->output = pi->output_max;
    if (pi->output < pi->output_min) pi->output = pi->output_min;
    
    return pi->output;
}
